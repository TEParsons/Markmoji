from .markmoji import markmoji, Markmoji
from . import authors, handlers

from packaging.version import Version

__version__ = Version("1.2.1")